# Django Login/Signup App

A basic login system built with Django, using Django's built-in auth
system and an SQLite database (a real SQL database, created via
Django's ORM/migrations).

## What's included
- `accounts/` app with signup, login, logout, and a protected home page
- `accounts/forms.py` — signup form (extends Django's UserCreationForm)
- `accounts/views.py` — signup_view, login_view, logout_view, home_view
- `accounts/urls.py` — routes: /signup/, /login/, /logout/, /
- `templates/base.html` + `accounts/templates/accounts/*.html` — pages
- `db.sqlite3` — the SQL database, already created and migrated
  (contains Django's auth_user table etc. — no existing accounts yet)

## Setup (using your existing virtual environment)

1. Copy this `loginproject` folder wherever you keep your code, and
   activate your virtual environment.
2. Install Django (if not already installed):
   ```
   pip install django
   ```
3. From inside the `loginproject` folder, run the server:
   ```
   python manage.py runserver
   ```
4. Open http://127.0.0.1:8000/signup/ in your browser to create an
   account, or http://127.0.0.1:8000/login/ if you already have one.

## Notes
- The database is already migrated. If you ever change `accounts/models.py`
  in the future, run:
  ```
  python manage.py makemigrations
  python manage.py migrate
  ```
- To view/manage the database via Django's admin panel, create a superuser:
  ```
  python manage.py createsuperuser
  ```
  then log in at http://127.0.0.1:8000/admin/
- Password rules are Django's defaults (min length, not too similar to
  username, not a common password, not all numeric). Adjust
  `AUTH_PASSWORD_VALIDATORS` in `settings.py` if you want to loosen these.
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
# FDS-Login-Page
